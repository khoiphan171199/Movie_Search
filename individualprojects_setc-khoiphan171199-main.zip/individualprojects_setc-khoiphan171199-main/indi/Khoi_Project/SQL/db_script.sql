DROP TABLE IF EXISTS artist_reviews CASCADE;
CREATE TABLE IF NOT EXISTS  artist_reviews (
    id SERIAL PRIMARY KEY,  
    name TEXT NOT NULL
);
