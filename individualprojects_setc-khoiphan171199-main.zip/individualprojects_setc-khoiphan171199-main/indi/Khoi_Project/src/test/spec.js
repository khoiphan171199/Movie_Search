// Imports the server.js file to be tested.
const server = require("../server");
// Assertion (Test Driven Development) and Should,  Expect(Behaviour driven 
// development) library
const chai = require("chai");
// Chai HTTP provides an interface for live integration testing of the API's.
const chaiHttp = require("chai-http");
chai.should();
chai.use(chaiHttp);
const { assert, expect } = chai;

describe("Server!", () => {
  // Sample test case given to test / endpoint.
  it("Returns the default welcome message", (done) => {
    chai
      .request(server)
      .get("/")
      .end((err, res) => {
        expect(res).to.have.status(200);
        expect(res.body.status).to.equals("success");
        assert.strictEqual(res.body.message, "Welcome!");
        done();
      });
  });

  // ===========================================================================
  // TODO: Please add your test cases for part A here.

  it('Is a non-empty array', function(done){
    chai
    .request(server)
    .get("/Reviews")
    .end((err, res) => {
      assert.strictEqual(res.body[0].id, 1) // Confirms getting operations response
      expect(res.body).to.be.an('array'); // Confirms is an array
      assert.notStrictEqual(res.body.length, 0); // Confirms not empty array
    });
    done();
  });

  it('Id is 1, has name and sign', function(done){
    chai
    .request(server)
    .get("/operations/1")
    .end((err, res) => {
      assert.strictEqual(res.body.id, 1) // Check id is 1
      expect(res.body.name).to.not.be.null // Check name exists
      expect(res.body.sign).to.not.be.null // Check sign exists
    });
    done();
  });

  it('Id is 4, has correct name and sign', function(done){
    chai
    .request(server)
    .post("/operations")
    .send({name: 'Divide', sign: '/'})
    .end((err, res) => {
      assert.strictEqual(res.body.id, 4) // Check id is 4
      assert.strictEqual(res.body.name, 'Divide') // Check name is Divide
      assert.strictEqual(res.body.sign, '/') // Check sign is /
      //expect(res.body.name).to.not.be.null
      //expect(res.body.sign).to.not.be.null
    });
    done();
  });

  // ===========================================================================
  // TODO: Please add your test cases for part B here.

  it('Should Show Movie Name, review, Date',(done) =>{
    chai 
      .request(server)
      .post('/Review')
      .send({Artist_Name: "ColdPlay"})
      .end((err, res) => { 
        expect(res).to.have.status(200);
        expect(res.body.result).to.equal("ColdPlay, ColdPlay Review, 08-19-2022");
      done();
      })
  });
  it('Should show nothing, since the movie Does not exist',(done) =>{
    chai 
      .request(server)
      .post('/Review')
      .send({Artist_Name: "Ready to ooga some booga"})
      .end((err, res) => { 
        expect(res).to.have.status(200);
        expect(res.body.result).to.equal(" ");
      done();
      })
  });
  }); 