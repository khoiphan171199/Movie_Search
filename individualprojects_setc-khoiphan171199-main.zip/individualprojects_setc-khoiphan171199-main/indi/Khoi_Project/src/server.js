var express = require('express'); //Ensure our express framework has been added
var app = express();
var bodyParser = require('body-parser'); //Ensure our body-parser tool has been added
app.use(bodyParser.json());              // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

const dev_dbConfig = {
	host: 'db',
	port: 5432,
	database: 'music_db',
	user:  'postgres',
	password: 'pwd'
};

var pgp = require('pg-promise')();
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(express.static(__dirname + '/'));
const isProduction = process.env.NODE_ENV === 'production';
const dbConfig = isProduction ? process.env.DATABASE_URL : dev_dbConfig;

// Heroku Postgres patch for v10
// fixes: https://github.com/vitaly-t/pg-promise/issues/711
if (isProduction) {
  pgp.pg.defaults.ssl = {rejectUnauthorized: false};
}
var db = pgp(dbConfig);
app.get('/', function(req, res) {
	res.render('Pages/home');
});

app.get('/home', function(req, res) {
	res.render('Pages/home');
});

// registration page
app.post('/Review', function(req, res) {
	var name = req.body.ArtistName;
	var insert_statement ="INSERT INTO artist_reviews(name) Values ('" + name +  "');";
	var artist_select ='select * from  artist_reviews;'; // Write a SQL statement to retrieve all of the colors in the favorite_colors table
	db.task('get-everything', task => {
		return task.batch([
			task.any(insert_statement),
			task.any(artist_select),
		]);
	})
	.then(info => {
		res.render('Pages/Review',{
                artist_select: info[1],
				Artist:info[1]
			})
	})
	.catch(err => {
		console.log('Uh Oh I made an oopsie1');
			console.log('error', err);
			res.render('Pages/Review', {
				artist_select: '',
				Artist:''
			})
	});
});

app.get('/Review', function(req, res) {
	var artist_select = 'select * from artist_reviews';
	db.task('get-everything', task => {
		return task.batch([
			task.any(artist_select)
		]);
	})
	.then(info => {
		res.render('Pages/Review',{
			artist_select: info[0],
			Artist:info[0],
		})
	})
	.catch(err => {
			console.log('error', err);
			res.render('Pages/Review',{
				artist_select: '',
				Artist:'' 
			})
	});
});

app.post('/Review/Filter', function(req, res) {
	var Artist_name = req.body.artist_name;
	var dispaly_name = "select * from artist_reviews where name = '" + Artist_name + "';";
	var artist_select ='select * from  artist_reviews;'; // Write a SQL statement to retrieve all of the colors in the favorite_colors table
	if(Artist_name)
	{
		db.task('get-everything', task => {
			return task.batch([
				task.any(artist_select),
				task.any(dispaly_name)
			]);
		})
		.then(info => {
			//console.log("Artist is: " + Artist_name);
			res.render('Pages/Review',{
                    artist_select: info[0],
					Artist:info[1]
				})
		})
		.catch(err => {
			console.log('Uh Oh I made an oopsie1');
				console.log('error', err);
				res.render('pages/review', {
					artist_select: '',
					Artist:''
				})
		});
	}
});

app.get('/Review/Filter', function(req, res) {
	var artist_select ='select * from  artist_reviews;';
	db.task('get-everything', task => {
		return task.batch([
			task.any(artist_select)
		]);
	})
	.then(info => {
		res.render('Pages/Review',{
			artist_select: info[0],
			Artist:info[0],
		})
	})
	.catch(err => {
			console.log('error', err);
			res.render('Pages/Review',{
				artist_select: '',
				Artist:''
			})
	});
});
app.listen(process.env.PORT || 3000, function(){
	console.log("Express server listening on port %d in %s mode", this.address().port, app.settings.env);
  });