$(document).ready(function()
{
    $("#Artistform").submit(function(event)
    {
        event.preventDefault()
        var singer = $("#Artist").val()
        var url = "https://www.theaudiodb.com/api/v1/json/2/search.php?s="+singer
        var result = " "
        
        $.ajax(
            {
                method:'GET',
                url: url,
                success:function(artist)
                {   
                    console.log(artist);

                    result =
                    `
                        <img style="float:left" class ="img-thumbnail"  width ="200" height = "200" src ="${artist.artists[0].strArtistThumb}"/>
                        <h6 style="position: absolute; left: 450px;">${artist.artists[0].strArtist}</h6>
                        <div>
                        <h6 style="position: absolute; left: 450px; top:200px;">Total members</h6>
                            <p  style="position: absolute; left: 450px; top:220px;">${artist.artists[0].intMembers} </p>
                        </div>
                        <div>
                        <h6 style="position: absolute; left: 450px; top:260px;">Style</h6>
                            <p  style="position: absolute; left: 450px; top:280px;">${artist.artists[0].strStyle} </p>
                        </div>
                        <div>
                        <h6 style="position: absolute; left: 450px; top:350px;">Year Formed</h6>
                                <p style="position: absolute; left: 450px; top:380px;">${artist.artists[0].intFormedYear} </p>
                        </div>
                        <div>
                        <h6 style="position: absolute; left: 450px; top:430px;">bio</h6>
                                <p style="position: absolute; left: 450px; top:470px;">${artist.artists[0].strBiographyEN} </p>
                        </div>
                    </div>
                        </div>
                        
                    </div>
                        <a href ="#myModal"class="btn btn-info" data-toggle="modal"<button style="position:absolute; bottom:150px; left:200px" class="button"> Add Review</button> </a> 
                        <div id="myModal" class="modal fade">
                            <div class="modal-dialog modal-login">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">Add Review</h4>
                                    <button
                                    type="button"
                                    class="close"
                                    data-dismiss="modal"
                                    aria-hidden="true"
                                    >
                                    &times;
                                    </button>
                                </div>
                                <form action="/Review" method="POST" id="review_form-2">
                                <div class="modal-body">
                                    <div class="form-group">
                                    <input
                                        readonly
                                        type="text"
                                        class="form-control"
                                        name="ArtistName"
                                        value="${artist.artists[0].strArtist} "
                                        required="required"
                                    />
                                    </div>
                                    <div class="form-group">
                                   <button  onclick="/home.href"  id="Add" class="btn btn-primary btn-block login-btn" style= "background-color:green">
                                    Yes
                                    </button>
                                    <button class="close, btn btn-primary btn-block login-btn"style= "background-color:red" data-dismiss="modal">
                                    No 
                                    </button>
                                    </div>
                                    </form>
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                     `
                    $("#Display").html(result)
                }, 
                error: function(XMLHttpRequest, textStatus, errorThrown) {
       console.log(textStatus, errorThrown, XMLHttpRequest);
    }
            })
    })
})